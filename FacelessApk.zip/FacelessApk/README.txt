FACELESS BOT v2.2 - ANDROID APK PROJECT
=======================================
BUILD (Termux):
  cd ~ && rm -rf FacelessApk && unzip -o ~/storage/downloads/FacelessApk.zip
  cd FacelessApk && echo "sdk.dir=$HOME/android-sdk" > local.properties
  gradle assembleDebug --no-daemon
  cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/FacelessBot.apk

NAYA V2:
 - AI voice (Gemini TTS, male motivational voices) + alag Voice API key
 - Video pehle internet milte hi banta hai, YouTube par SCHEDULED upload hota hai
 - Background me chalta hai (foreground service), band app par bhi
 - Tabs: Home / Settings / About (Terms, Privacy, License)
 - Naya logo aur design

V2.1: adhura kaam save (resume), chhoti images (slow net ke liye), Network+Voice test button,
progress bar, auto-post ab har din naya schedule banata hai (self-heal).
V2.2: ek waqt me sirf ek video run (files delete hone wala error fix).
