package com.faceless.bot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Store {
    private fun p(c: Context) = c.getSharedPreferences("fb", Context.MODE_PRIVATE)
    fun get(c: Context, k: String, d: String = ""): String = p(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { p(c).edit().putString(k, v).commit() }
    @Synchronized
    fun log(c: Context, m: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        put(c, "log", (get(c, "log") + "\n" + t + " " + m).takeLast(5000))
    }
}

object Net {
    val FORM = mapOf("Content-Type" to "application/x-www-form-urlencoded")
    val JSON = mapOf("Content-Type" to "application/json")

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    fun form(m: Map<String, String>): String = m.entries.joinToString("&") { enc(it.key) + "=" + enc(it.value) }

    fun request(url: String, method: String = "GET", headers: Map<String, String> = emptyMap(),
                body: ByteArray? = null, timeout: Int = 60000): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = timeout
        c.readTimeout = timeout
        for ((k, v) in headers) c.setRequestProperty(k, v)
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, text)
    }

    fun download(url: String, f: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    }

    fun downloadRetry(url: String, f: File, tries: Int = 2) {
        var last: Exception? = null
        for (i in 1..tries) {
            try { download(url, f); return } catch (e: Exception) { last = e; Thread.sleep(2000) }
        }
        throw last ?: Exception("download failed")
    }
}

object Auth {
    private const val SCOPE = "https://www.googleapis.com/auth/youtube.upload"
    private const val TOKEN_URL = "https://oauth2.googleapis.com/token"

    fun connect(c: Context, show: (String, String) -> Unit) {
        val id = Store.get(c, "client_id").trim()
        val sec = Store.get(c, "client_secret").trim()
        if (id.isEmpty() || sec.isEmpty()) {
            Store.log(c, "Pehle Client ID aur Secret daalkar Save karo")
            return
        }
        try {
            val (code, res) = Net.request("https://oauth2.googleapis.com/device/code", "POST", Net.FORM,
                Net.form(mapOf("client_id" to id, "scope" to SCOPE)).toByteArray())
            if (code != 200) { Store.log(c, "Login error: " + res.take(300)); return }
            val j = JSONObject(res)
            val userCode = j.getString("user_code")
            val url = j.optString("verification_url", "https://www.google.com/device")
            Store.log(c, "Browser me ye code daalo: $userCode (copy ho gaya)")
            show(url, userCode)
            var interval = j.optInt("interval", 5)
            val end = System.currentTimeMillis() + j.optInt("expires_in", 600) * 1000L
            while (System.currentTimeMillis() < end) {
                Thread.sleep(interval * 1000L)
                val (c2, r2) = Net.request(TOKEN_URL, "POST", Net.FORM, Net.form(mapOf(
                    "client_id" to id, "client_secret" to sec,
                    "device_code" to j.getString("device_code"),
                    "grant_type" to "urn:ietf:params:oauth:grant-type:device_code")).toByteArray())
                val t = JSONObject(r2)
                if (t.has("refresh_token")) {
                    Store.put(c, "refresh_token", t.getString("refresh_token"))
                    Store.log(c, "YouTube connected! Ab Run Now dabao.")
                    return
                }
                val err = t.optString("error")
                if (err == "slow_down") interval += 5
                else if (err != "authorization_pending") { Store.log(c, "Login failed: " + r2.take(300)); return }
            }
            Store.log(c, "Time khatam, dobara Connect dabao")
        } catch (e: Exception) {
            Store.log(c, "Login exception: " + e.message)
        }
    }

    fun accessToken(c: Context): String {
        val rt = Store.get(c, "refresh_token")
        if (rt.isEmpty()) throw Exception("YouTube connect nahi hai")
        val (code, res) = Net.request(TOKEN_URL, "POST", Net.FORM, Net.form(mapOf(
            "client_id" to Store.get(c, "client_id").trim(),
            "client_secret" to Store.get(c, "client_secret").trim(),
            "refresh_token" to rt, "grant_type" to "refresh_token")).toByteArray())
        if (code != 200) throw Exception("Token error, dobara Connect karo: " + res.take(200))
        return JSONObject(res).getString("access_token")
    }
}

class Script(val title: String, val desc: String, val tags: List<String>, val scenes: List<Pair<String, String>>)

object Topics {
    val presets = listOf(
        "Motivation and success", "Amazing science facts", "Space and universe", "Ancient history",
        "Mystery and unsolved cases", "Health and fitness tips", "Money and business tips",
        "Technology and AI", "Animals and nature", "Short horror stories", "Life hacks", "Psychology facts")

    fun resolve(c: Context): String {
        return when (val ch = Store.get(c, "niche_choice", "MIX")) {
            "MIX" -> presets.random()
            "CUSTOM" -> Store.get(c, "niche_custom").ifBlank { presets[0] }
            else -> ch
        }
    }
}

object Gemini {
    fun script(c: Context): Script {
        val lang = if (Store.get(c, "language", "en").trim() == "hi") "Hindi (Devanagari script)" else "English"
        val n = Store.get(c, "scenes", "6").trim().toIntOrNull() ?: 6
        val used = Store.get(c, "hist", "none")
        val niche = Topics.resolve(c)
        val prompt = """Create a YouTube Short (about 40-50 seconds) for a faceless channel about: $niche.
Do NOT repeat these earlier titles: $used
Narration language: $lang.
Return ONLY JSON in this exact shape:
{"title":"catchy title under 70 chars","description":"2 short lines","tags":["t1","t2","t3","t4","t5"],"scenes":[{"narration":"1-2 short sentences","keyword":"2-3 ENGLISH words for a stock photo search"}]}
Exactly $n scenes. The first scene must be a strong hook."""
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 1.0))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            Store.get(c, "gemini_model", "gemini-2.5-flash").trim() + ":generateContent?key=" + Store.get(c, "gemini_key").trim()
        var last = ""
        for (a in 1..3) {
            val (code, res) = Net.request(url, "POST", Net.JSON, body.toString().toByteArray(), 90000)
            if (code == 200) {
                var txt = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                txt = txt.replace("```json", "").replace("```", "").trim()
                val d = JSONObject(txt)
                val arr = d.getJSONArray("scenes")
                val scenes = ArrayList<Pair<String, String>>()
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    scenes.add(Pair(s.getString("narration"), s.optString("keyword", "nature")))
                }
                val tags = ArrayList<String>()
                val ta = d.optJSONArray("tags")
                if (ta != null) for (i in 0 until ta.length()) tags.add(ta.getString(i))
                if (scenes.isEmpty()) throw Exception("Gemini ne scenes nahi diye")
                return Script(d.getString("title"), d.optString("description", ""), tags, scenes)
            }
            last = "$code " + res.take(200)
            if (code == 400 || code == 403) break
            Thread.sleep(8000)
        }
        throw Exception("Gemini error: $last")
    }
}

object Pexels {
    @Volatile var lastSource = ""
    fun load(f: File): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600 || o.outHeight / s > 1600) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(f.path, o2)
    }

    fun image(c: Context, kw: String, f: File): Bitmap? {
        lastSource = ""
        val uk = Store.get(c, "unsplash_key").trim()
        if (uk.isNotEmpty()) {
            for (q in listOf(kw, "nature landscape")) {
                try {
                    val hd = mapOf("Authorization" to "Client-ID $uk", "Accept-Version" to "v1")
                    val (code, res) = Net.request("https://api.unsplash.com/search/photos?orientation=portrait&per_page=15&query=" +
                        Net.enc(q), "GET", hd)
                    if (code != 200) continue
                    val arr = JSONObject(res).getJSONArray("results")
                    if (arr.length() == 0) continue
                    val photo = arr.getJSONObject(Random().nextInt(arr.length()))
                    val raw = photo.getJSONObject("urls").getString("raw")
                    Net.downloadRetry(raw + (if (raw.contains("?")) "&" else "?") + "w=720&h=1280&fit=crop&q=70", f)
                    try { Net.request(photo.getJSONObject("links").getString("download_location"), "GET", hd) } catch (e: Exception) { }
                    val b = load(f)
                    if (b != null) { lastSource = "Unsplash"; return b }
                } catch (e: Exception) { }
            }
        }
        val key = Store.get(c, "pexels_key").trim()
        if (key.isNotEmpty()) for (q in listOf(kw, "nature landscape")) {
            try {
                val (code, res) = Net.request("https://api.pexels.com/v1/search?orientation=portrait&per_page=15&query=" + Net.enc(q),
                    "GET", mapOf("Authorization" to key))
                if (code != 200) continue
                val arr = JSONObject(res).getJSONArray("photos")
                if (arr.length() == 0) continue
                val u = arr.getJSONObject(Random().nextInt(arr.length())).getJSONObject("src").getString("portrait")
                Net.downloadRetry(u, f, 1)
                val b = load(f)
                if (b != null) { lastSource = "Pexels"; return b }
            } catch (e: Exception) { }
        }
        // Pixabay (free key)
        val pk = Store.get(c, "pixabay_key").trim()
        if (pk.isNotEmpty()) {
            for (q in listOf(kw, "nature landscape")) {
                try {
                    val (code, res) = Net.request("https://pixabay.com/api/?key=" + Net.enc(pk) +
                        "&image_type=photo&orientation=vertical&safesearch=true&per_page=20&q=" + Net.enc(q.take(90)))
                    if (code != 200) continue
                    val arr = JSONObject(res).getJSONArray("hits")
                    if (arr.length() == 0) continue
                    val u = arr.getJSONObject(Random().nextInt(arr.length())).getString("webformatURL")
                    Net.downloadRetry(u, f, 1)
                    val b = load(f)
                    if (b != null) { lastSource = "Pixabay"; return b }
                } catch (e: Exception) { }
            }
        }
        // Fallback 1: free AI image (bina key), 3 koshish
        for (t in 1..2) {
            try {
                val u = "https://image.pollinations.ai/prompt/" + Net.enc("$kw, cinematic, vertical, high quality") +
                    "?width=720&height=1280&nologo=true&seed=" + Random().nextInt(100000)
                Net.downloadRetry(u, f, 1)
                val b = load(f)
                if (b != null) { lastSource = "AI image"; return b }
            } catch (e: Exception) { }
            try { Thread.sleep(3000) } catch (e: Exception) { }
        }
        // Fallback 2: Picsum (random real photo, bina key)
        try {
            Net.downloadRetry("https://picsum.photos/seed/" + Random().nextInt(100000) + "/720/1280", f, 1)
            val b = load(f)
            if (b != null) { lastSource = "Picsum photo"; return b }
        } catch (e: Exception) { }
        lastSource = "none"
        return null
    }
}

class Pcm(val data: ByteArray, val rate: Int, val ch: Int)

object Wav {
    fun read(f: File): Pcm {
        val b = f.readBytes()
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        var rate = 22050
        var ch = 1
        var pos = 12
        while (pos + 8 <= b.size) {
            val id = String(b, pos, 4, Charsets.US_ASCII)
            var sz = bb.getInt(pos + 4)
            if (id == "fmt ") {
                ch = bb.getShort(pos + 10).toInt()
                rate = bb.getInt(pos + 12)
            }
            if (id == "data") {
                if (sz <= 0 || pos + 8 + sz > b.size) sz = b.size - pos - 8
                val align = 2 * ch
                sz -= sz % align
                return Pcm(b.copyOfRange(pos + 8, pos + 8 + sz), rate, ch)
            }
            if (sz < 0) break
            pos += 8 + sz + (sz and 1)
        }
        throw Exception("WAV data nahi mila")
    }
}

class Speaker(private val ctx: Context) {
    private var tts: TextToSpeech? = null

    fun init(lang: String) {
        val latch = CountDownLatch(1)
        var ok = false
        Handler(Looper.getMainLooper()).post {
            tts = TextToSpeech(ctx.applicationContext) { st ->
                ok = (st == TextToSpeech.SUCCESS)
                latch.countDown()
            }
        }
        if (!latch.await(20, TimeUnit.SECONDS) || !ok) throw Exception("Phone ka TTS engine start nahi hua")
        val r = tts!!.setLanguage(Locale(lang))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            throw Exception("Phone me '$lang' voice nahi hai. Settings > Text-to-speech me voice install karo")
    }

    fun speak(text: String, f: File) {
        val latch = CountDownLatch(1)
        var ok = false
        tts!!.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ok = true; latch.countDown() }
            override fun onError(id: String?) { latch.countDown() }
        })
        val r = tts!!.synthesizeToFile(text, Bundle(), f, "u" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS || !latch.await(60, TimeUnit.SECONDS) || !ok)
            throw Exception("TTS audio nahi bana")
    }

    fun close() { tts?.shutdown() }
}

object Uploader {
    fun upload(c: Context, token: String, s: Script, file: File, publishAt: String?): String {
        val st = JSONObject()
            .put("privacyStatus", if (publishAt != null) "private" else Store.get(c, "privacy", "private").trim())
            .put("selfDeclaredMadeForKids", false)
        if (publishAt != null) st.put("publishAt", publishAt)
        val meta = JSONObject()
            .put("snippet", JSONObject().put("title", s.title.take(95))
                .put("description", s.desc + "\n\n#Shorts").put("tags", JSONArray(s.tags)).put("categoryId", "22"))
            .put("status", st)
        val h = URL("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
            .openConnection() as HttpURLConnection
        h.requestMethod = "POST"
        h.doOutput = true
        h.setRequestProperty("Authorization", "Bearer $token")
        h.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        h.setRequestProperty("X-Upload-Content-Type", "video/mp4")
        h.outputStream.use { it.write(meta.toString().toByteArray()) }
        if (h.responseCode != 200)
            throw Exception("Upload start " + h.responseCode + ": " + (h.errorStream?.bufferedReader()?.readText() ?: "").take(300))
        val loc = h.getHeaderField("Location") ?: throw Exception("Upload URL nahi mila")
        val p = URL(loc).openConnection() as HttpURLConnection
        p.requestMethod = "PUT"
        p.doOutput = true
        p.connectTimeout = 60000
        p.readTimeout = 600000
        p.setFixedLengthStreamingMode(file.length())
        p.setRequestProperty("Content-Type", "video/mp4")
        file.inputStream().use { i -> p.outputStream.use { o -> i.copyTo(o) } }
        val code = p.responseCode
        val body = (if (code in 200..299) p.inputStream else p.errorStream)?.bufferedReader()?.readText() ?: ""
        if (code !in 200..299) throw Exception("Upload error $code: " + body.take(300))
        return JSONObject(body).getString("id")
    }
}
