package com.faceless.bot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.util.Base64
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object Audio {
    const val RATE = 24000

    private fun bytes(a: ShortArray): ByteArray {
        val bb = ByteBuffer.allocate(a.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.asShortBuffer().put(a)
        return bb.array()
    }

    // koi bhi audio ko 24kHz mono 16-bit me badalta hai
    fun norm(p: Pcm): Pcm {
        val src = ByteBuffer.wrap(p.data).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val frames = p.data.size / (2 * p.ch)
        val mono = ShortArray(frames) { i ->
            var sum = 0
            for (k in 0 until p.ch) sum += src.get(i * p.ch + k).toInt()
            (sum / p.ch).toShort()
        }
        if (p.rate == RATE) return Pcm(bytes(mono), RATE, 1)
        val outN = (frames.toLong() * RATE / p.rate).toInt()
        val out = ShortArray(outN) { i ->
            val pos = i.toDouble() * p.rate / RATE
            val i0 = minOf(pos.toInt(), frames - 1)
            val i1 = minOf(i0 + 1, frames - 1)
            val fr = pos - i0
            (mono[i0] * (1 - fr) + mono[i1] * fr).toInt().toShort()
        }
        return Pcm(bytes(out), RATE, 1)
    }
}

object GeminiVoice {
    fun speak(c: Context, text: String): Pcm {
        val key = Store.get(c, "voice_key").trim().ifEmpty { Store.get(c, "gemini_key").trim() }
        if (key.isEmpty()) throw Exception("Voice API key nahi hai")
        val voice = Store.get(c, "voice_name", "Orus")
        val style = Store.get(c, "voice_style", "deep, confident and motivational")
        val lang = if (Store.get(c, "language", "en").trim() == "hi") "in Hindi" else "in English"
        val prompt = "Say $lang in a $style tone: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val models = listOf(Store.get(c, "voice_model", "gemini-2.5-flash-preview-tts").trim(),
            "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts").filter { it.isNotEmpty() }.distinct()
        var last = ""
        for (m in models) {
            for (a in 1..3) {
                val (code, res) = Net.request("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                    "POST", Net.JSON + ("x-goog-api-key" to key), body.toString().toByteArray(), 120000)
                if (code == 200) {
                    val b64 = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
                    val raw = Base64.decode(b64, Base64.DEFAULT)
                    return Pcm(raw.copyOf(raw.size and -2), 24000, 1)
                }
                last = "$m $code " + res.take(120)
                if (code == 429) Thread.sleep(30000)
                else if (code == 404 || code == 400 || code == 403) break
                else Thread.sleep(4000)
            }
        }
        throw Exception("Voice API: $last")
    }
}

object NetUtil {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return true
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun validated(c: Context): Boolean {
        val cm = c.getSystemService(ConnectivityManager::class.java) ?: return true
        val n = cm.activeNetwork ?: return false
        return cm.getNetworkCapabilities(n)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    }

    fun waitOnline(c: Context) {
        val end = System.currentTimeMillis() + 3 * 60 * 1000
        while (!online(c)) {
            if (System.currentTimeMillis() > end) throw IOException("Internet nahi mila")
            Thread.sleep(5000)
        }
        var t = 0
        while (t < 4 && !validated(c)) { Thread.sleep(5000); t++ }
    }

    fun <T> retry(c: Context, f: () -> T): T {
        var last: Exception? = null
        for (a in 1..4) {
            try {
                return f()
            } catch (e: IOException) {
                last = e
                Store.log(c, "Network dikkat: " + Friendly.explain(e) + " - dobara try ($a/4)")
                Thread.sleep(20000L * a)
                try { waitOnline(c) } catch (x: Exception) { }
            }
        }
        throw last ?: Exception("network error")
    }
}

object Notifier {
    private fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fb", "Working", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("fb_done", "Results", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun working(c: Context): ForegroundInfo {
        channels(c)
        val n = Notification.Builder(c, "fb").setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Faceless Bot").setContentText("Video ban raha hai...").setOngoing(true).build()
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(1, n)
    }

    fun done(c: Context, title: String, text: String) {
        try {
            channels(c)
            val n = Notification.Builder(c, "fb_done").setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle(title).setContentText(text).setAutoCancel(true).build()
            c.getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (e: Exception) { }
    }
}

object Sched {
    fun parse(s: String, dh: Int, dm: Int): Pair<Int, Int> {
        val p = s.split(":")
        val h = (p.getOrNull(0)?.trim()?.toIntOrNull() ?: dh).coerceIn(0, 23)
        val m = (p.getOrNull(1)?.trim()?.toIntOrNull() ?: dm).coerceIn(0, 59)
        return Pair(h, m)
    }

    fun nextPublish(c: Context): Calendar? {
        if (Store.get(c, "upload_mode", "schedule") != "schedule") return null
        val (h, m) = parse(Store.get(c, "post_time", "18:00"), 18, 0)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis < System.currentTimeMillis() + 20 * 60 * 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal
    }

    fun iso(cal: Calendar): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(cal.time)
    }
}

object Friendly {
    fun explain(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "Internet/DNS nahi mil raha (" + (e.message ?: "").substringAfter("\"").substringBefore("\"") + ")"
        is java.net.SocketTimeoutException -> "Internet bahut slow hai (timeout)"
        is java.net.ConnectException -> "Server se connect nahi ho paya"
        is java.io.IOException -> "Network error: " + e.message
        else -> e.message ?: e.javaClass.simpleName
    }
}

object ScriptIO {
    fun toJson(s: Script): String {
        val a = JSONArray()
        for ((n, k) in s.scenes) a.put(JSONObject().put("n", n).put("k", k))
        return JSONObject().put("title", s.title).put("desc", s.desc).put("tags", JSONArray(s.tags)).put("scenes", a).toString()
    }

    fun fromJson(t: String): Script {
        val d = JSONObject(t)
        val a = d.getJSONArray("scenes")
        val sc = ArrayList<Pair<String, String>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            sc.add(Pair(o.getString("n"), o.getString("k")))
        }
        val tg = ArrayList<String>()
        val ta = d.optJSONArray("tags")
        if (ta != null) for (i in 0 until ta.length()) tg.add(ta.getString(i))
        return Script(d.getString("title"), d.optString("desc", ""), tg, sc)
    }
}

object Diag {
    fun run(c: Context) {
        Store.log(c, "--- Network test shuru ---")
        val tests = listOf(
            "Gemini (Google)" to "https://generativelanguage.googleapis.com/",
            "YouTube upload" to "https://www.googleapis.com/",
            "Unsplash" to "https://api.unsplash.com/",
            "Pexels" to "https://api.pexels.com/",
            "Pixabay" to "https://pixabay.com/",
            "AI images" to "https://image.pollinations.ai/",
            "Picsum photos" to "https://picsum.photos/")
        for ((n, u) in tests) {
            val t0 = System.currentTimeMillis()
            try {
                val cn = URL(u).openConnection() as HttpURLConnection
                cn.connectTimeout = 15000
                cn.readTimeout = 15000
                val code = cn.responseCode
                Store.log(c, "OK   $n (" + (System.currentTimeMillis() - t0) + " ms, HTTP $code)")
            } catch (e: Exception) {
                Store.log(c, "FAIL $n: " + Friendly.explain(e))
            }
        }
        try {
            val t0 = System.currentTimeMillis()
            val p = GeminiVoice.speak(c, "Hello, this is a voice test.")
            Store.log(c, "OK   AI voice (" + (System.currentTimeMillis() - t0) / 1000 + " sec, " + p.data.size / 1024 + " KB)")
        } catch (e: Exception) {
            Store.log(c, "FAIL AI voice: " + Friendly.explain(e))
        }
        Store.log(c, "--- Network test khatam ---")
    }
}

object Scheduler {
    private fun nextRun(c: Context): Calendar {
        val (h, m) = Sched.parse(Store.get(c, "generate_time", "10:00"), 10, 0)
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 60000) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal
    }

    fun scheduleNext(c: Context) {
        if (Store.get(c, "auto_on") != "1") return
        val cal = nextRun(c)
        val name = "daily-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(cal.time)
        val req = OneTimeWorkRequest.Builder(BotWorker::class.java)
            .setInitialDelay(cal.timeInMillis - System.currentTimeMillis(), TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES)
            .setInputData(Data.Builder().putBoolean("auto", true).build())
            .addTag("daily")
            .build()
        WorkManager.getInstance(c).enqueueUniqueWork(name, ExistingWorkPolicy.KEEP, req)
        Store.put(c, "next_run", cal.time.toString())
    }

    fun start(c: Context) {
        WorkManager.getInstance(c).cancelAllWorkByTag("daily")
        Store.put(c, "auto_on", "1")
        scheduleNext(c)
        Store.log(c, "Auto-post chalu. Agla video: " + Store.get(c, "next_run") + ", publish time: " + Store.get(c, "post_time", "18:00"))
    }

    fun stop(c: Context) {
        WorkManager.getInstance(c).cancelAllWorkByTag("daily")
        Store.put(c, "auto_on", "0")
        Store.put(c, "next_run", "")
        Store.log(c, "Auto-post band")
    }

    fun heal(c: Context) {
        if (Store.get(c, "auto_on") != "1") return
        Thread {
            try {
                val infos = WorkManager.getInstance(c).getWorkInfosByTag("daily").get()
                if (infos.none { !it.state.isFinished }) scheduleNext(c)
            } catch (e: Exception) { }
        }.start()
    }
}
