package com.faceless.bot

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BotWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val c = applicationContext
        val auto = inputData.getBoolean("auto", false)
        try { setForegroundAsync(Notifier.working(c)) } catch (e: Throwable) { }
        val stamp = { SimpleDateFormat("dd MMM HH:mm", Locale.US).format(Date()) }
        return try {
            Pipeline.run(c)
            Store.put(c, "last_result", "OK " + stamp())
            if (auto) Scheduler.scheduleNext(c)
            Result.success()
        } catch (e: Throwable) {
            val msg = Friendly.explain(e)
            Store.log(c, "ERROR: $msg")
            Store.put(c, "progress", "0")
            Store.put(c, "step", "Ruk gaya: $msg")
            if (runAttemptCount < 3) {
                Store.log(c, "Adhura kaam save hai. 15 min baad wahin se dobara chalega.")
                Result.retry()
            } else {
                Store.put(c, "last_result", "FAIL " + stamp())
                Notifier.done(c, "Video nahi ban paya", msg.take(120))
                if (auto) Scheduler.scheduleNext(c)
                Result.failure()
            }
        }
    }
}

object Pipeline {
    private fun prog(c: Context, p: Int, msg: String) {
        Store.put(c, "progress", p.toString())
        Store.put(c, "step", msg)
        Store.log(c, msg)
    }

    private fun voices(c: Context, texts: List<String>, dir: File): List<Pcm> {
        val mode = File(dir, "voice_mode")
        val useAi = Store.get(c, "voice_engine", "ai") == "ai" && !(mode.exists() && mode.readText() == "phone")
        if (useAi) {
            try {
                return texts.mapIndexed { i, t ->
                    val f = File(dir, "a$i.pcm")
                    if (f.exists() && f.length() > 0) {
                        Pcm(f.readBytes(), Audio.RATE, 1)
                    } else {
                        Store.put(c, "step", "AI awaaz " + (i + 1) + "/" + texts.size)
                        val p = Audio.norm(NetUtil.retry(c) { GeminiVoice.speak(c, t) })
                        f.writeBytes(p.data)
                        Thread.sleep(4000)
                        p
                    }
                }
            } catch (e: Exception) {
                Store.log(c, "AI voice nahi chali: " + Friendly.explain(e) + " -> phone voice use hogi")
                dir.listFiles()?.filter { it.name.endsWith(".pcm") }?.forEach { it.delete() }
                mode.writeText("phone")
            }
        }
        val sp = Speaker(c)
        try {
            sp.init(Store.get(c, "language", "en").trim())
            return texts.mapIndexed { i, t ->
                val f = File(dir, "a$i.pcm")
                if (f.exists() && f.length() > 0) {
                    Pcm(f.readBytes(), Audio.RATE, 1)
                } else {
                    val w = File(dir, "s$i.wav")
                    sp.speak(t, w)
                    val p = Audio.norm(Wav.read(w))
                    f.writeBytes(p.data)
                    p
                }
            }
        } finally {
            sp.close()
        }
    }

    private val running = java.util.concurrent.atomic.AtomicBoolean(false)

    fun run(c: Context) {
        if (!running.compareAndSet(false, true)) {
            Store.log(c, "Dusra video pehle se ban raha hai, ye run skip kiya.")
            return
        }
        try { runInner(c) } finally { running.set(false) }
    }

    private fun runInner(c: Context) {
        prog(c, 5, "Internet check...")
        NetUtil.waitOnline(c)

        val dir = File(c.filesDir, "job")
        dir.mkdirs()
        val sf = File(dir, "script.json")
        if (sf.exists() && System.currentTimeMillis() - sf.lastModified() > 6 * 3600 * 1000L) {
            dir.deleteRecursively()
            dir.mkdirs()
        }
        val script: Script
        if (sf.exists()) {
            script = ScriptIO.fromJson(sf.readText())
            Store.log(c, "Adhura kaam mila, wahin se jaari: " + script.title)
        } else {
            prog(c, 10, "1/4 Script ban rahi hai...")
            script = NetUtil.retry(c) { Gemini.script(c) }
            sf.writeText(ScriptIO.toJson(script))
            Store.log(c, "Title: " + script.title)
        }

        val out = File(dir, "final.mp4")
        val okMark = File(dir, "video_ok")
        if (!(out.exists() && okMark.exists())) {
            prog(c, 25, "2/4 Awaaz ban rahi hai...")
            val pcms = voices(c, script.scenes.map { it.first }, dir)

            prog(c, 50, "2/4 Images aa rahi hain...")
            val all = ByteArrayOutputStream()
            val bmps = ArrayList<android.graphics.Bitmap?>()
            val secsList = ArrayList<Double>()
            for ((i, s) in script.scenes.withIndex()) {
                val pcm = pcms[i]
                all.write(pcm.data)
                all.write(ByteArray(12000))
                secsList.add(pcm.data.size / 2.0 / Audio.RATE + 0.25)
                val f = File(dir, "i$i.jpg")
                var bmp: android.graphics.Bitmap? = null
                if (f.exists() && f.length() > 1000) bmp = Pexels.load(f)
                if (bmp != null) {
                    Store.log(c, "Scene " + (i + 1) + " image: cache")
                } else {
                    bmp = Pexels.image(c, s.second, f)
                    Store.log(c, "Scene " + (i + 1) + " image: " + Pexels.lastSource)
                }
                bmps.add(bmp)
            }
            val anyBmp = bmps.firstOrNull { it != null }
            val scenes = ArrayList<SceneData>()
            for ((i, s) in script.scenes.withIndex()) scenes.add(SceneData(bmps[i] ?: anyBmp, s.first, secsList[i]))

            prog(c, 65, "3/4 Video ban rahi hai (1-3 min)...")
            val v = File(dir, "v.mp4")
            val a = File(dir, "a.m4a")
            VideoMaker.makeVideo(scenes, v)
            VideoMaker.makeAudio(all.toByteArray(), Audio.RATE, 1, a)
            VideoMaker.merge(v, a, out)
            okMark.writeText("1")
        } else {
            Store.log(c, "Video pehle se bana hai, seedha upload.")
        }

        val cal = Sched.nextPublish(c)
        prog(c, 90, if (cal != null) "4/4 Upload (scheduled: " + cal.time.toString() + ")" else "4/4 YouTube par upload...")
        NetUtil.waitOnline(c)
        val pub = if (cal != null) Sched.iso(cal) else null
        val id = NetUtil.retry(c) { Uploader.upload(c, Auth.accessToken(c), script, out, pub) }
        Store.put(c, "hist", (script.title + " | " + Store.get(c, "hist", "")).take(1500))
        prog(c, 100, "Ho gaya!")
        Store.log(c, "DONE! https://youtube.com/shorts/$id")
        Notifier.done(c, if (cal != null) "Video scheduled" else "Video upload ho gaya", script.title)
        dir.deleteRecursively()
    }
}
