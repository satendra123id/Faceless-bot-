package com.faceless.bot

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

class SceneData(val bmp: Bitmap?, val text: String, val seconds: Double) {
    var layout: StaticLayout? = null
}

object VideoMaker {
    const val W = 720
    const val H = 1280
    const val FPS = 30

    private fun textPaint(): TextPaint {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE
        tp.textSize = 46f
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.setShadowLayer(8f, 0f, 0f, Color.BLACK)
        return tp
    }

    private fun draw(c: Canvas, sc: SceneData, z: Float, p: Paint) {
        c.drawColor(Color.BLACK)
        val b = sc.bmp
        if (b != null) {
            val s = max(W / b.width.toFloat(), H / b.height.toFloat()) * z
            val m = Matrix()
            m.postScale(s, s)
            m.postTranslate((W - b.width * s) / 2f, (H - b.height * s) / 2f)
            c.drawBitmap(b, m, p)
        } else {
            val gp = Paint()
            gp.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), Color.rgb(60, 40, 150), Color.rgb(10, 10, 35), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), gp)
        }
        val lay = sc.layout
        if (lay != null) {
            val shade = Paint()
            shade.color = Color.argb(120, 0, 0, 0)
            val top = H * 0.62f
            c.drawRect(0f, top - 30f, W.toFloat(), top + lay.height + 30f, shade)
            c.save()
            c.translate(50f, top)
            lay.draw(c)
            c.restore()
        }
    }

    fun makeVideo(scenes: List<SceneData>, out: File) {
        val tp = textPaint()
        for (s in scenes) {
            s.layout = StaticLayout.Builder.obtain(s.text, 0, s.text.length, tp, W - 100)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).build()
        }
        val fmt = MediaFormat.createVideoFormat("video/avc", W, H)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 2500000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val enc = MediaCodec.createEncoderByType("video/avc")
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var base = -1L
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean) {
            if (end) enc.signalEndOfInputStream()
            var spin = 0
            while (true) {
                val i = enc.dequeueOutputBuffer(info, if (end) 10000L else 0L)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return
                    if (++spin > 500) return
                } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.outputFormat)
                    mux.start()
                    started = true
                } else if (i >= 0) {
                    val buf = enc.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        if (base < 0) base = info.presentationTimeUs
                        info.presentationTimeUs = info.presentationTimeUs - base
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        mux.writeSampleData(track, buf, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            val t0 = System.nanoTime()
            var n = 0L
            for (sc in scenes) {
                val frames = max(1, (sc.seconds * FPS).toInt())
                for (f in 0 until frames) {
                    val z = 1f + 0.12f * f / frames
                    val canvas = surface.lockCanvas(null)
                    draw(canvas, sc, z, paint)
                    surface.unlockCanvasAndPost(canvas)
                    drain(false)
                    n++
                    val wait = (t0 + n * 1000000000L / FPS - System.nanoTime()) / 1000000L
                    if (wait > 0) Thread.sleep(wait)
                }
            }
            drain(true)
        } finally {
            try { enc.stop() } catch (e: Exception) { }
            enc.release()
            surface.release()
            try { mux.stop() } catch (e: Exception) { }
            mux.release()
        }
    }

    fun makeAudio(pcm: ByteArray, rate: Int, ch: Int, out: File) {
        val fmt = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, ch)
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 96000)
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32768)
        val enc = MediaCodec.createEncoderByType("audio/mp4a-latm")
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var started = false
        var pos = 0
        var inDone = false
        var outDone = false
        val info = MediaCodec.BufferInfo()
        val frameBytes = 2 * ch
        try {
            while (!outDone) {
                if (!inDone) {
                    val ii = enc.dequeueInputBuffer(10000L)
                    if (ii >= 0) {
                        val ib = enc.getInputBuffer(ii)!!
                        ib.clear()
                        var n = minOf(ib.capacity(), pcm.size - pos)
                        n -= n % frameBytes
                        val pts = (pos / frameBytes).toLong() * 1000000L / rate
                        if (n <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            ib.put(pcm, pos, n)
                            enc.queueInputBuffer(ii, 0, n, pts, 0)
                            pos += n
                        }
                    }
                }
                val oi = enc.dequeueOutputBuffer(info, 10000L)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mux.addTrack(enc.outputFormat)
                    mux.start()
                    started = true
                } else if (oi >= 0) {
                    val ob = enc.getOutputBuffer(oi)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        mux.writeSampleData(track, ob, info)
                    }
                    enc.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                }
            }
        } finally {
            try { enc.stop() } catch (e: Exception) { }
            enc.release()
            try { mux.stop() } catch (e: Exception) { }
            mux.release()
        }
    }

    fun merge(v: File, a: File, out: File) {
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val ex = listOf(v, a).map { f ->
            val e = MediaExtractor()
            e.setDataSource(f.path)
            e.selectTrack(0)
            e
        }
        val tracks = ex.map { mux.addTrack(it.getTrackFormat(0)) }
        mux.start()
        val buf = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        while (true) {
            var k = -1
            var best = Long.MAX_VALUE
            for (i in ex.indices) {
                val t = ex[i].sampleTime
                if (t >= 0 && t < best) { best = t; k = i }
            }
            if (k < 0) break
            buf.clear()
            val n = ex[k].readSampleData(buf, 0)
            if (n < 0) break
            info.set(0, n, ex[k].sampleTime, ex[k].sampleFlags)
            mux.writeSampleData(tracks[k], buf, info)
            ex[k].advance()
        }
        for (e in ex) e.release()
        mux.stop()
        mux.release()
    }
}
