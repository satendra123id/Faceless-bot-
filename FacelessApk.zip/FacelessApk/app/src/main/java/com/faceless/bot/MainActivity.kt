package com.faceless.bot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.io.File
import java.util.Calendar
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val fields = LinkedHashMap<String, EditText>()
    private val choices = LinkedHashMap<String, Pair<Spinner, List<String>>>()
    private val pages = ArrayList<View>()
    private val tabs = ArrayList<TextView>()
    private lateinit var cur: LinearLayout
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var recentView: TextView
    private lateinit var stepView: TextView
    private lateinit var progressBar: ProgressBar
    private val h = Handler(Looper.getMainLooper())

    private val primary = Color.rgb(91, 61, 245)
    private val green = Color.rgb(32, 160, 96)
    private val grey = Color.rgb(110, 115, 135)
    private val red = Color.rgb(200, 60, 60)
    private val txt = Color.rgb(30, 30, 45)
    private val pageBg = Color.rgb(244, 245, 250)
    private val match = LinearLayout.LayoutParams.MATCH_PARENT

    private val tick = object : Runnable {
        override fun run() {
            val l = Store.get(this@MainActivity, "log", "")
            logView.text = if (l.isBlank()) "(status yahan dikhega)" else l.trim()
            statusView.text = statusText()
            progressBar.progress = Store.get(this@MainActivity, "progress", "0").toIntOrNull() ?: 0
            stepView.text = Store.get(this@MainActivity, "step", "").ifBlank { "Abhi koi kaam nahi chal raha" }
            val hist = Store.get(this@MainActivity, "hist", "").split(" | ").filter { it.isNotBlank() }.take(3)
            recentView.text = if (hist.isEmpty()) "Abhi koi video nahi" else hist.joinToString("\n") { "\u2022 $it" }
            h.postDelayed(this, 2000)
        }
    }

    private fun statusText(): String {
        fun ok(b: Boolean) = if (b) "\u2705" else "\u274C"
        val yt = Store.get(this, "refresh_token").isNotEmpty()
        val gem = Store.get(this, "gemini_key").isNotEmpty()
        val auto = Store.get(this, "auto_on") == "1"
        val sb = StringBuilder()
        sb.append(ok(gem)).append(" Gemini key\n")
        sb.append(ok(yt)).append(" YouTube connected\n")
        sb.append(ok(auto)).append(" Auto-post ").append(if (auto) "ON" else "OFF")
        if (auto) {
            sb.append("\n     Agla video banega: ").append(Store.get(this, "next_run", "-"))
            sb.append("\n     YouTube publish time: ").append(Store.get(this, "post_time", "18:00"))
        }
        val last = Store.get(this, "last_result")
        if (last.isNotEmpty()) sb.append("\nLast run: ").append(last)
        return sb.toString()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(match, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(8)
        return l
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val rootCol = LinearLayout(this)
        rootCol.orientation = LinearLayout.VERTICAL
        val frame = FrameLayout(this)
        rootCol.addView(frame, LinearLayout.LayoutParams(match, 0, 1f))
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(Color.WHITE)
        bar.elevation = dp(8).toFloat()
        rootCol.addView(bar, LinearLayout.LayoutParams(match, dp(58)))
        setContentView(rootCol)

        fun page(): LinearLayout {
            val sv = ScrollView(this)
            sv.setBackgroundColor(pageBg)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(16), dp(20), dp(16), dp(24))
            sv.addView(col)
            frame.addView(sv)
            pages.add(sv)
            return col
        }
        cur = page(); buildHome()
        cur = page(); buildSettings()
        cur = page(); buildAbout()

        for ((i, n) in listOf("Home", "Settings", "About").withIndex()) {
            val t = TextView(this)
            t.text = n
            t.gravity = Gravity.CENTER
            t.textSize = 13f
            t.setOnClickListener { showTab(i) }
            bar.addView(t, LinearLayout.LayoutParams(0, match, 1f))
            tabs.add(t)
        }
        showTab(0)
        h.post(tick)
        Scheduler.heal(this)
    }

    override fun onPause() { save(); super.onPause() }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun showTab(i: Int) {
        for (k in pages.indices) {
            pages[k].visibility = if (k == i) View.VISIBLE else View.GONE
            tabs[k].setTextColor(if (k == i) primary else grey)
            tabs[k].setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    // ---------------- HOME ----------------
    private fun buildHome() {
        header("Faceless Bot", "Roz 1 YouTube Short - script se upload tak, auto")
        val s = card("Status")
        statusView = TextView(this)
        statusView.textSize = 14f
        statusView.setTextColor(txt)
        statusView.setPadding(0, dp(8), 0, 0)
        s.addView(statusView)
        note(s, "Kuch \u274C ho to Settings tab me jakar bharo.")

        val pc = card("Abhi ka kaam")
        stepView = TextView(this)
        stepView.textSize = 13.5f
        stepView.setTextColor(txt)
        stepView.setPadding(0, dp(8), 0, dp(6))
        pc.addView(stepView)
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.progressTintList = ColorStateList.valueOf(primary)
        pc.addView(progressBar, LinearLayout.LayoutParams(match, dp(10)))

        val a = card("Chalao")
        btn(a, "Run Now (abhi 1 video banao)", green) {
            save()
            val req = OneTimeWorkRequest.Builder(BotWorker::class.java)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
            WorkManager.getInstance(this).enqueue(req)
            Store.log(this, "Run queue me gaya. Internet milte hi chalega (1-4 min).")
        }
        btn(a, "Roz auto-post chalu karo") { save(); Scheduler.start(this) }
        btn(a, "Auto-post band karo", red) { Scheduler.stop(this) }
        btn(a, "Battery optimization hatao (zaroori)", grey) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) { toast("Settings > Apps > Faceless Bot > Battery > Unrestricted") }
        }

        btn(a, "Network + Voice test (problem dhundho)", grey) { save(); Thread { Diag.run(this) }.start() }
        btn(a, "Adhura kaam hatao (naya video shuru)", grey) {
            File(filesDir, "job").deleteRecursively()
            Store.put(this, "progress", "0")
            Store.put(this, "step", "")
            Store.log(this, "Adhura kaam hata diya")
        }

        val r = card("Pichhle videos")
        recentView = TextView(this)
        recentView.textSize = 13.5f
        recentView.setTextColor(txt)
        recentView.setPadding(0, dp(8), 0, 0)
        r.addView(recentView)

        val l = card("Live status")
        logView = TextView(this)
        logView.textSize = 12f
        logView.typeface = Typeface.MONOSPACE
        logView.setTextColor(Color.rgb(150, 255, 190))
        logView.background = bg(Color.rgb(20, 22, 34), 10)
        logView.setPadding(dp(12), dp(12), dp(12), dp(12))
        logView.setTextIsSelectable(true)
        l.addView(logView, lp())
        btn(l, "Clear log", grey) { Store.put(this, "log", "") }
    }

    // ---------------- SETTINGS ----------------
    private fun buildSettings() {
        header("Settings", "Saari API keys aur options yahan")

        val k = card("API keys (free)")
        note(k, "Link dabao, login karke key copy karke paste karo. Keys sirf is phone me save hoti hain.")
        field(k, "gemini_key", "Gemini API key (script ke liye, zaroori)", "", "https://aistudio.google.com/apikey", "Gemini key yahan se lo (free)")
        field(k, "voice_key", "Voice API key (AI awaaz, khali = upar wali key)", "", "https://aistudio.google.com/apikey", "Voice ke liye alag key: yahin se doosri key banao")
        field(k, "unsplash_key", "Unsplash Access Key (optional)", "", "https://unsplash.com/oauth/applications", "Unsplash Access Key (Secret nahi chahiye)")
        field(k, "pexels_key", "Pexels API key (optional)", "", "https://www.pexels.com/api/", "Pexels key (abhi pause ho sakti hai)")
        field(k, "pixabay_key", "Pixabay API key (optional)", "", "https://pixabay.com/api/docs/", "Pixabay key yahan se lo")
        note(k, "Image order: Unsplash, Pexels, Pixabay, phir bina key wali free AI images.")

        val t = card("Video topic")
        val topicOpts = Topics.presets.map { it to it } +
            listOf("MIX" to "Mix - roz alag topic", "CUSTOM" to "Custom - apna topic likho")
        val sp = choice(t, "niche_choice", "Topic chuno", topicOpts, "MIX")
        val custom = field(t, "niche_custom", "Apna topic (jaise: Bollywood trivia)")
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                custom.visibility = if (topicOpts[pos].first == "CUSTOM") View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        choice(t, "language", "Video ki bhasha", listOf("en" to "English", "hi" to "Hindi"), "en")
        choice(t, "scenes", "Scenes (zyada = lamba video)",
            listOf("4" to "4", "5" to "5", "6" to "6", "7" to "7", "8" to "8"), "6")

        val v = card("Awaaz (Voice)")
        choice(v, "voice_engine", "Voice type", listOf("ai" to "AI voice (natural, Gemini)", "phone" to "Phone voice (offline)"), "ai")
        choice(v, "voice_name", "AI voice chuno", listOf(
            "Orus" to "Orus - Male, firm (motivation)", "Charon" to "Charon - Male, deep & calm",
            "Fenrir" to "Fenrir - Male, energetic", "Puck" to "Puck - Male, upbeat",
            "Kore" to "Kore - Female, firm", "Aoede" to "Aoede - Female, bright"), "Orus")
        choice(v, "voice_style", "Bolne ka style", listOf(
            "deep, confident and motivational" to "Motivational (gambhir)", "calm, slow storytelling" to "Calm storyteller",
            "energetic and excited" to "Energetic", "neutral and clear" to "Neutral"), "deep, confident and motivational")
        note(v, "AI voice na chale to app apne aap phone ki awaaz use karta hai. Hindi ke liye phone me Hindi voice install ho to behtar.")

        val s = card("Schedule")
        field(s, "generate_time", "Video banane ka time HH:MM", "10:00")
        field(s, "post_time", "YouTube par publish time HH:MM", "18:00")
        choice(s, "upload_mode", "Upload mode", listOf(
            "schedule" to "Scheduled (pehle upload, time par auto public)",
            "now" to "Turant (privacy neeche wali)"), "schedule")
        choice(s, "privacy", "Privacy (sirf Turant mode me)", listOf(
            "private" to "Private", "unlisted" to "Unlisted", "public" to "Public"), "private")
        note(s, "Video internet milte hi ban kar upload ho jata hai. Publish time par YouTube khud public karta hai, tab phone ki zarurat nahi. Naye Google project me video private lock ho sakta hai.")

        val y = card("YouTube connect")
        note(y, "Steps: (a) API enable (b) Consent screen me apna Gmail Test user banao (c) OAuth client ID banao, type: TVs and Limited Input devices (d) ID aur Secret neeche daalo.")
        link(y, "(a) YouTube Data API v3 Enable karo", "https://console.cloud.google.com/apis/library/youtube.googleapis.com")
        link(y, "(b) OAuth consent screen / Audience", "https://console.cloud.google.com/auth/audience")
        link(y, "(c) OAuth Client ID banao", "https://console.cloud.google.com/apis/credentials")
        field(y, "client_id", "Google OAuth Client ID")
        field(y, "client_secret", "Google OAuth Client Secret")
        btn(y, "Connect YouTube") {
            save()
            Thread {
                Auth.connect(this) { url, code ->
                    runOnUiThread {
                        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("code", code))
                        open(url)
                    }
                }
            }.start()
        }

        val adv = card("Advanced")
        field(adv, "gemini_model", "Script model", "gemini-2.5-flash")
        field(adv, "voice_model", "Voice model", "gemini-2.5-flash-preview-tts")
        btn(cardEnd(), "Save settings", primary) { save(); toast("Saved") }
    }

    private fun cardEnd(): LinearLayout = cur

    // ---------------- ABOUT ----------------
    private fun buildAbout() {
        header("About", "Faceless Bot \u2022 Version 2.2")
        val a = card("Ye app kya karta hai")
        note(a, "Topic se script likhta hai (Gemini), awaaz banata hai, images lagata hai, 9:16 Short banata hai aur aapke YouTube channel par scheduled upload kar deta hai. Sab kuch aapke phone se, bina kisi server ke.")
        expand("Terms & Conditions", TERMS)
        expand("Privacy Policy", PRIVACY)
        expand("License", LICENSE)
        expand("Open-source notices", NOTICES)
        link(cur, "Apna YouTube access hatao (Google permissions)", "https://myaccount.google.com/permissions")
        note(cur, "\u00A9 2026 Faceless Bot. Sabhi third-party naam unke maalikon ke hain.")
    }

    // ---------------- UI helpers ----------------
    private fun header(title: String, sub: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageResource(R.mipmap.ic_launcher)
        row.addView(img, LinearLayout.LayoutParams(dp(60), dp(60)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, 0, 0)
        val t = TextView(this)
        t.text = title
        t.textSize = 24f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(txt)
        val s = TextView(this)
        s.text = sub
        s.textSize = 13f
        s.setTextColor(grey)
        col.addView(t)
        col.addView(s)
        row.addView(col)
        cur.addView(row)
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(Color.WHITE, 16)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        c.elevation = dp(2).toFloat()
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 17f
        tv.setTypeface(null, Typeface.BOLD)
        tv.setTextColor(primary)
        c.addView(tv)
        val p = lp()
        p.topMargin = dp(16)
        cur.addView(c, p)
        return c
    }

    private fun expand(title: String, body: String) {
        val c = card("$title  \u25BE")
        val tv = TextView(this)
        tv.text = body
        tv.textSize = 13f
        tv.setTextColor(txt)
        tv.setPadding(0, dp(10), 0, 0)
        tv.visibility = View.GONE
        c.addView(tv)
        c.setOnClickListener { tv.visibility = if (tv.visibility == View.GONE) View.VISIBLE else View.GONE }
    }

    private fun note(p: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 12.5f
        tv.setTextColor(grey)
        tv.setPadding(0, dp(6), 0, dp(2))
        p.addView(tv)
    }

    private fun caption(p: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 13f
        tv.setTextColor(txt)
        tv.setPadding(0, dp(10), 0, 0)
        p.addView(tv)
    }

    private fun link(p: LinearLayout, t: String, url: String) {
        val tv = TextView(this)
        tv.text = "\uD83D\uDD17 $t"
        tv.textSize = 13.5f
        tv.setTextColor(Color.rgb(25, 100, 210))
        tv.setPadding(0, dp(6), 0, dp(4))
        tv.setOnClickListener { open(url) }
        p.addView(tv)
    }

    private fun field(p: LinearLayout, key: String, hint: String, def: String = "",
                      url: String? = null, linkText: String? = null): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setSingleLine()
        e.setText(Store.get(this, key, def))
        e.textSize = 14f
        e.setTextColor(txt)
        e.background = bg(Color.rgb(248, 249, 252), 10, Color.rgb(210, 212, 225))
        e.setPadding(dp(12), dp(12), dp(12), dp(12))
        p.addView(e, lp())
        fields[key] = e
        if (url != null) link(p, linkText ?: "Free key yahan se lo", url)
        return e
    }

    private fun choice(p: LinearLayout, key: String, label: String,
                       opts: List<Pair<String, String>>, def: String): Spinner {
        caption(p, label)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts.map { it.second })
        val cur0 = Store.get(this, key, def)
        val idx = opts.indexOfFirst { it.first == cur0 }
        sp.setSelection(if (idx < 0) 0 else idx)
        sp.background = bg(Color.rgb(248, 249, 252), 10, Color.rgb(210, 212, 225))
        sp.setPadding(dp(8), dp(10), dp(8), dp(10))
        p.addView(sp, lp())
        choices[key] = Pair(sp, opts.map { it.first })
        return sp
    }

    private fun btn(p: LinearLayout, t: String, color: Int = primary, f: () -> Unit) {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.background = bg(color, 12)
        b.stateListAnimator = null
        b.setOnClickListener { f() }
        val l = lp()
        l.height = dp(50)
        l.topMargin = dp(10)
        p.addView(b, l)
    }

    private fun open(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        catch (e: Exception) { toast("Browser nahi khula") }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun save() {
        for ((k, e) in fields) Store.put(this, k, e.text.toString().trim())
        for ((k, v) in choices) Store.put(this, k, v.second[v.first.selectedItemPosition])
        for (k in listOf("generate_time", "post_time")) {
            val (hh, mm) = Sched.parse(Store.get(this, k, ""), if (k == "post_time") 18 else 10, 0)
            val t = "%02d:%02d".format(hh, mm)
            Store.put(this, k, t)
            fields[k]?.setText(t)
        }
    }

    companion object {
        const val TERMS = """1. Acceptance
By using Faceless Bot you agree to these terms.

2. Personal tool
The app helps you create and upload videos to your own YouTube channel. You are fully responsible for all content you publish.

3. Third-party services
The app uses Google Gemini, YouTube Data API and optional image services (Unsplash, Pexels, Pixabay, Pollinations). You must follow their terms, including the YouTube Terms of Service, YouTube API Services Terms, YouTube Community Guidelines and each image provider's license and attribution rules.

4. AI-generated content
Videos are created with AI. Review them before publishing and follow YouTube's policies on altered or synthetic content and on repetitive or low-effort content.

5. No warranty
The app is provided "as is". Generation or upload can fail because of API limits, quotas, network problems or policy changes.

6. Limitation of liability
The developer is not liable for any loss, channel strike, demonetization or account action resulting from use of the app.

7. Changes
These terms may change in future versions."""

        const val PRIVACY = """Your API keys, settings and YouTube login token are stored only on this device, in the app's private storage. The app has no server and the developer does not receive your data.

Data is sent only to the services you enable, to create and upload your videos: Google (Gemini, YouTube) and the optional image providers (Unsplash, Pexels, Pixabay, Pollinations).

To delete everything: Android Settings > Apps > Faceless Bot > Storage > Clear data. To revoke YouTube access: myaccount.google.com/permissions."""

        const val LICENSE = """Faceless Bot, Copyright (c) 2026.

The person who builds or installs this app may use it for personal and commercial purposes with their own accounts. Redistribution or resale of the app itself requires permission.

Images and audio created with third-party services remain subject to those services' licenses (Unsplash License, Pexels License, Pixabay Content License, Google Gemini terms)."""

        const val NOTICES = """AndroidX WorkManager - Apache License 2.0.
AndroidX and Kotlin standard library - Apache License 2.0.
Licensed under the Apache License, Version 2.0; you may obtain a copy at https://www.apache.org/licenses/LICENSE-2.0"""
    }
}
